    Namn: Maximilian Widman, Ella Larsson och Kawan Majeed

    Hemsida: https://www.elgiganten.se och https://www.elgiganten.se/catalog/se_datorer_tillbehor/datorer-tillbehor
    
    Vi valde att avgränsa main 1 då det var väldigt mycket repetativa element även lite av det interaktiva som burger menyn och subkategorierna som ska komma upp när man hovrar på ett kategori element i headern för vi tänkte lägga mest fokus på att sidan är responsiv och att den ser bra ut för alla typer av enheter.

    Elgiganten blå #000e52
    Elgiganten grön #8cd600 hover grön #88d41b lime grön #88d000